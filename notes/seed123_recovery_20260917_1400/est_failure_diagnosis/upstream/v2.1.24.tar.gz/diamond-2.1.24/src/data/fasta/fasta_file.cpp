/****
Copyright (C) 2012-2026 Benjamin J. Buchfink <buchfink@gmail.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****/
// SPDX-License-Identifier: Apache-2.0

#include "fasta_file.h"
#include "util/sequence/sequence.h"

using std::vector;
using std::string;
using std::pair;
using std::runtime_error;
using std::unique_ptr;
using std::tie;
using std::ifstream;
using std::ofstream;
using std::next;
using namespace Util::Tsv;
using Util::String::TokenizerBase;
using Util::String::FastaTokenizer;
using Util::String::FastqTokenizer;

static const Schema FASTA_SCHEMA { Type::STRING, Type::STRING };
static const Schema FASTQ_SCHEMA{ Type::STRING, Type::STRING, Type::STRING };
//const char* FASTA_SEP = "\n>", * FASTQ_SEP = "\n@";

SeqFileFormat guess_format(TextInputFile& file) {
	string r = file.peek(1);
	if (r.empty())
		throw std::runtime_error("Error detecting input file format. Input file seems to be empty.");
	switch (r.front()) {
	case '>': return SeqFileFormat::FASTA;
	case '@': return SeqFileFormat::FASTQ;
	default: throw std::runtime_error("Error detecting input file format. First line must begin with '>' (FASTA) or '@' (FASTQ).");
	}
}

FastaFile::FastaFile(const std::vector<std::string>& file_name, Flags flags, const ValueTraits& value_traits, const std::string& index_file):
	SequenceFile(SequenceFile::Type::FASTA, flags, FormatFlags::DICT_LENGTHS | FormatFlags::DICT_SEQIDS, value_traits),
	oid_(0)
{
	if (file_name.size() > 2)
		throw OperationNotSupported();
	if (bool(flags & (Flags::TAXON_MAPPING | Flags::TAXON_NODES | Flags::TAXON_RANKS | Flags::TAXON_SCIENTIFIC_NAMES)))
		throw runtime_error("Fasta database format does not support taxonomic features.");
	unique_ptr<TextInputFile> input_file(new TextInputFile(file_name.front()));
	format_ = guess_format(*input_file);
	//Util::Tsv::Config config(format_ == SeqFileFormat::FASTA ? FASTA_SEP : FASTQ_SEP, format_ == SeqFileFormat::FASTA ? (TokenizerBase*)(new FastaTokenizer()) : new FastqTokenizer);
	Util::Tsv::Config config(format_ == SeqFileFormat::FASTA ? (TokenizerBase*)(new FastaTokenizer()) : new FastqTokenizer);
	const auto schema = format_ == SeqFileFormat::FASTA ? FASTA_SCHEMA : FASTQ_SCHEMA;
	file_.emplace_back(schema, std::move(input_file), Util::Tsv::Flags(), config);
	if (file_name.size() > 1)
		file_.emplace_back(schema, file_name[1], Util::Tsv::Flags(), config);
	file_ptr_ = file_.begin();	
	if (!flag_any(flags, Flags::NEED_LETTER_COUNT))
		return;
	tie(seqs_, letters_) = init_read(index_file);
	set_seqinfo_ptr(0);
}

FastaFile::FastaFile(const string& file_name, bool overwrite, const WriteAccess&, Flags flags, const ValueTraits& value_traits):
	SequenceFile(SequenceFile::Type::FASTA, flags, FormatFlags::DICT_LENGTHS | FormatFlags::DICT_SEQIDS, value_traits),
	out_file_(file_name.empty() ? new TempFile : new OutputFile(file_name, Compressor::NONE, overwrite ? "w+b" : "r+b")),
	format_(SeqFileFormat::FASTA),
	oid_(0),
	seqs_(0),
	letters_(0)
{
	unique_ptr<TextInputFile> in(new TextInputFile(*out_file_));
	//Util::Tsv::Config config(FASTA_SEP, new FastaTokenizer());
	Util::Tsv::Config config(new FastaTokenizer());
	file_.emplace_back(FASTA_SCHEMA, std::move(in), Util::Tsv::Flags(), config);
	//file_.emplace_back(*out_file_);
	file_ptr_ = file_.begin();
	if (!overwrite) {
		vector<Letter> seq;
		string id;
		while (read_seq(seq, id, nullptr)) {
			++seqs_;
			letters_ += seq.size();
		}
	}
}

int64_t FastaFile::file_count() const {
	return file_.size();
}

bool FastaFile::files_synced() {
	if (file_ptr_ != file_.begin())
		return false;
	if (file_ptr_->eof()) {
		string id;
		vector<Letter> seq;
		if (next(file_ptr_) != file_.end() && !next(file_ptr_)->read_record().empty())
			return false;
	}
	return true;
}

SequenceFile::SeqInfo FastaFile::read_seqinfo() {
	throw OperationNotSupported();
}

void FastaFile::putback_seqinfo() {
	throw OperationNotSupported();
}

void FastaFile::close() {
	if (out_file_)
		file_.front().close();
	else
		for (auto& f : file_)
			f.close();
	
}

void FastaFile::set_seqinfo_ptr(OId i) {
	if (out_file_)
		out_file_->rewind();
	if (index_.empty()) {
		for (auto& f : file_)
			f.rewind();
		oid_ = 0;
		vector<Letter> seq;
		string id;
		while (oid_ != i) {
			read_seq(seq, id, nullptr);
		}
	}
	else {
		if (file_.size() != 1 || i >= index_.size())
			throw runtime_error("FastaFile::set_seqinfo_ptr");
		file_.front().seek(index_[i]);
	}
}

OId FastaFile::tell_seq() const {
	return oid_;
}

bool FastaFile::eof() const {
	return file_.back().eof();
}

void FastaFile::init_seq_access() {
	set_seqinfo_ptr(0);
}

bool FastaFile::read_seq(vector<Letter>& seq, string &id, std::vector<char>* quals)
{
	oid_++;
	Table t = file_ptr_->read_record();
	if (!t.empty()) {
		id = t.front().get<string>(0);
		Util::Seq::from_string(t.front().get<string>(1), seq, value_traits_, 0);
		if (format_ == SeqFileFormat::FASTQ && quals) {
			const string q = Util::Seq::remove_newlines(t.front().get<string>(2));
			quals->assign(q.begin(), q.end());
		}
		if (++file_ptr_ == file_.end())
			file_ptr_ = file_.begin();
	}
	return !t.empty();
}

void FastaFile::create_partition_balanced(int64_t max_letters) {
	throw OperationNotSupported();
}

void FastaFile::save_partition(const string & partition_file_name, const string & annotation) {
	throw OperationNotSupported();
}

int FastaFile::get_n_partition_chunks() {
	throw OperationNotSupported();
}

void FastaFile::init_seqinfo_access() {
	throw OperationNotSupported();
}

void FastaFile::seek_chunk(const Chunk& chunk) {
	throw OperationNotSupported();
}

size_t FastaFile::id_len(const SeqInfo& seq_info, const SeqInfo& seq_info_next) {
	throw OperationNotSupported();
}

void FastaFile::seek_offset(size_t p) {
}

void FastaFile::read_seq_data(Letter* dst, size_t len, size_t& pos, bool seek) {
	throw OperationNotSupported();
}

void FastaFile::read_id_data(const int64_t oid, char* dst, size_t len, bool all, bool full_titles) {
	throw OperationNotSupported();
}

void FastaFile::skip_id_data() {
	throw OperationNotSupported();
}

uint64_t FastaFile::sequence_count() const {
	return seqs_;
}

uint64_t FastaFile::letters() const {
	return letters_;
}

int FastaFile::db_version() const {
	throw OperationNotSupported();
}

int FastaFile::program_build_version() const {
	throw OperationNotSupported();
}

int FastaFile::build_version() {
	throw OperationNotSupported();
}

FastaFile::~FastaFile()
{
	close();
}

DbFilter* FastaFile::filter_by_accession(const std::string& file_name)
{
	throw std::runtime_error("The FASTA database format does not support filtering by accession.");
}

std::string FastaFile::file_name()
{
	return file_.front().file_name();
}

std::vector<TaxId> FastaFile::taxids(size_t oid) const
{
	throw OperationNotSupported();
}

void FastaFile::seq_data(size_t oid, std::vector<Letter>& dst)
{
	throw OperationNotSupported();
}

Loc FastaFile::seq_length(size_t oid)
{
	if (oid < seq_length_.size())
		return seq_length_[oid];
	throw OperationNotSupported();
}

void FastaFile::end_random_access(bool dictionary)
{
	if (!dictionary)
		return;
	free_dictionary();
}

void FastaFile::init_write() {
	out_file_->seek(0, SEEK_END);
}

void FastaFile::write_seq(const Sequence& seq, const std::string& id) {
	static TextBuffer buf;
	Util::Seq::format(seq, id.c_str(), nullptr,  buf, "fasta", value_traits_);
	out_file_->write(buf.data(), buf.size());
	buf.clear();
	++seqs_;
	letters_ += seq.length();
	if (flag_any(flags_, Flags::NEED_LENGTH_LOOKUP))
		seq_length_.push_back(seq.length());
}

pair<int64_t, int64_t> FastaFile::init_read(const std::string& index_file) {
	vector<Letter> seq;
	string id;
	int64_t seqs = 0, letters = 0;
	if (index_file.empty()) {
		while (read_seq(seq, id)) {
			if (flag_any(flags_, Flags::ACC_TO_OID_MAPPING | Flags::OID_TO_ACC_MAPPING))
				add_seqid_mapping(id, seqs);
			if (flag_any(flags_, Flags::NEED_LENGTH_LOOKUP))
				seq_length_.push_back((Loc)seq.size());
			++seqs;
			letters += seq.size();
		}
	}
	else {
		ifstream in(index_file);
		if (!in)
			throw runtime_error("Error opening file: " + index_file);
		uint64_t offset;
		Loc len;
		while (in >> offset) {
			in >> len;
			index_.push_back(offset);
			seq_length_.push_back(len);
			++seqs;
			letters += len;
		}
	}
	return { seqs, letters };
}

void FastaFile::index(const string& path, const string& dst) {
	ofstream out(dst);
	auto f = [&](const string& id, const string& seq, std::streampos pos) {
		out << pos << '\t' << seq.length() << std::endl;
		};
	ifstream in(path);
	if (!in)
		throw runtime_error("Failed to open file: " + path);
	read_fasta(in, f);
}