# Runtime handshake recovery, 2026-09-17

Status: scoped software TODO complete. No commit, remote action, deployment authorization or GPU readiness claim. No operational receipts produced. Existing CPU test fixtures remain explicitly synthetic.

## Authority and exact hashes

Read independent accepted `/mnt/f/scratch/develop/Transgenic/transgenic_local/notes/seed123_execution_20260917/TRAIN_REVIEW.md`. Before repinning, actual integration-worktree source SHA256 matched its two reviewed snapshots. The unchanged runner matched the separately supplied retained pin. Rechecked all three after tests:

```text
7f9507f4fced687e1886c659224d4b778b3486a2b390dac1e8f3c6954e46c7ae  revision/scripts/mvp/real_probes.py
a5b2c895bd76699718655993d67430b9459c5db07d5f47636feb6acc77ce6de2  revision/scripts/mvp/make_launch_readiness.py
8b2f4042e03732c16d633fb66444b1b91e87cef54d3c696104775beebf19a932  revision/scripts/mvp/run_bounded.py
b0ffac46cff61f23262f5f8455a2217f823278b7b0225f4b9a445f8957db7d03  revision/scripts/mvp/mvp_decode_runtime.py
b8bbda7ea30880bba96a465183b4ec19f58cd5dd621dd946b6bff54415f2b391  tests/test_mvp_decoder_runtime.py
```

Production edits are only two PROBE_CODE values and their authority comments. Runtime checks, module exemptions and DECODER_ONLY were not changed by this task. The existing panel-compatibility DECODER_ONLY entry and corresponding test were already present on entry and are preserved. Scorer and other workers' files were untouched.

## Regression and evidence

The handshake regression now uses literal review-authorized digests independent of production PROBE_CODE. It exercises accepted closure with and without the historically absent runner import, wrong operator code pin, mutation of every handshake digest, and each stale integration digest. Existing d99 rejection tests remain.

Working directory: `/tmp/mvp-seed123-integration-20260917`.

Command prefix for every pytest invocation:

```sh
PYTHONPATH=src:revision/scripts/mvp OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/mvp-final-source-env/bin/python3.12 -m pytest -q
```

1. RED, before production edits: `tests/test_mvp_decoder_runtime.py -k probe_handshake_and_operator_code_pin --tb=short`. Result: 1 failed, 2 passed, 33 deselected in 2.78s. Approved closure failed with `unreviewed probe/handshake implementation`. Log: `red.log`.
2. Initial full-file check after pin edit: 21 passed, 1 skipped, 14 fixture errors in 21.30s. Root cause: bounded fixture still copied old 772c38c tooling, correctly failing its pin assertion. Log: `stale_fixture.log`. Updated only fixture sourcing to current local source bytes; retained exact pin assertions, real bounded runner exercise and synthetic CPU labels.
3. GREEN: `tests/test_mvp_decoder_runtime.py --tb=short`. Result: 35 passed, 1 skipped in 13.64s. Log: `green.log`. Skip is the existing pinned Transformers 4.57.6 loader contract when that version is unavailable. Installed-version CPU loader test passed; this is not SIF validation.
4. Scoped `git diff --check -- revision/scripts/mvp/mvp_decode_runtime.py tests/test_mvp_decoder_runtime.py` passed. Reviewed diff against entry state; preserved pre-existing panel work.

Graft consulted first: map, ranked runtime context and targeted skeletons. No broad suite or GPU execution. Fresh operational development-bound receipts and deployment decisions remain external gates, not asserted here.
