# Seed123 training/readiness implementation — 2026-09-17

Scope: isolated `/tmp/mvp-seed123-integration-20260917`, base `9603e20`. No commit. Controller owns integration/independent review/source freeze/deployment. Other workers' files are untouched.

## Shared API

`transgenic.training.mvp_profiles` is dependency-free:
- `LEGACY_PROFILE = 'historical-three-seed'`
- `DEVELOPMENT_PROFILE = 'development-single'`
- `validate_seed_profile(profile, seed) -> None`, raises `ValueError` for unknown/non-string profile, bool/float/string seed, or cross-profile seed. Legacy exact ints 1/2/3; development exact int 123. Explicit `None` is invalid; historical readers default only absent fields to legacy.

New deployment: explicit `--profile development-single --seed 123`. CLI parser accepts integer seed; validation occurs before candidate/model access. Direct execute/private training/probe setup/model loader and training wrapper also validate. Missing profile never makes seed123 legacy-valid.

## Identity and schema

- Fresh prepare/readiness bindings include `profile` and `run_role='mvp_finetune'`; canonical bindings SHA scopes all receipts. Consumed-code closure automatically includes the new helper.
- Fresh real-probe measurements include profile/seed/role. Receipt checking matches these against bindings for development; legacy receipts without these fields remain readable. Cross-profile bindings/receipt replay is rejected.
- Runtime passes profile to initial and final-publication readiness checks and includes profile/seed in cross-rank identity.
- Final metadata includes profile/role and seed123/aug_seed20261037. Development metadata requires the finetune role. Metadata validation also runs at publication, rejecting role changes after evaluation.
- `identity_scope='production'` retains real four-CUDA-rank hardware checks. Runtime labels remain exploratory, `production_authorized=False`, `runtime_profile='mvp_fixed_250x96'`.
- No recipe/data/model changes: fixed 250 updates, 12 warmup, 4 ranks, effective batch96, augmentation formula20260914+seed.
- Existing source checkpoint concrete-path/symlink/pin guards remain; source config seed must now be an exact int123. The intended deployment pin stays B5 epoch05; no mutable best resolution or checkpoint staging performed here.

Resource authorization:
- Schema1 retains exact `[1,2,3]`, legacy profile (absent allowed), `max_three_seed_node_hours`, and original three-run arithmetic/output field.
- Schema2 requires explicit profile development-single, exact `[123]`, numeric finite positive controller-provided `max_training_node_hours`; no default cap. Legacy cap field is rejected rather than reinterpreted.
- Both retain explicit bound digest, one-node/four-rank/24-microbatch resource envelope, margin/rationale, wall/launcher caps, memory headroom, prior smoke ledger, and unchanged combined five-node-hour probe ceiling.
- Schema2 `projected_training_node_hours = projected_run_seconds/3600`. Legacy `projected_three_seed_node_hours` is not emitted for schema2. Campaign projection adds prior smoke plus measured probe elapsed. No authorization file/cap or real receipt was fabricated.
- Wrapper validates full schema and actual readiness bindings hash before warmup/launch.

## Owned changed files

- `src/transgenic/training/mvp_profiles.py` (new)
- `src/transgenic/training/mvp_cli.py`
- `src/transgenic/training/mvp_cli_runtime.py`
- `src/transgenic/training/mvp_finalize.py`
- `revision/scripts/mvp/make_launch_readiness.py`
- `revision/scripts/mvp/real_probes.py`
- `revision/scripts/mvp/resource_probe.py`
- `revision/scripts/mvp/run_training.py`
- `tests/test_mvp_seed123_training.py` (new)
- `tests/test_mvp_cli.py`: preserve negative legacy-seed assertions at explicit-validator boundary instead of removed argparse choices.
- `tests/test_mvp_readiness_tools.py`: replace incomplete legacy launcher fixture budget with full schema1 fixture; no production bypass.
- `tasknotes/seed123_train/IMPLEMENTATION.md` and final scoped test log.

## Tests and limits

Interpreter throughout pytest: `/tmp/mvp-final-source-env/bin/python3.12`; `PYTHONPATH=src:revision/scripts/mvp`; no dependency installs.

Baseline before implementation:
1. `-m pytest -q tests/test_mvp_readiness_tools.py tests/test_mvp_readiness_review.py tests/test_mvp_resource_probe.py tests/test_mvp_resource_fix1.py`: **157 passed**.
2. Initial CLI/finalizer selection accidentally included finalizer subprocess tests using the preexisting hardcoded `/home/wyim/miniconda3/envs/pdb/bin/torchrun` and external dependency directories; it showed failures and hit120-second command timeout. No success claim for that run, and failures were not classified conclusively. Narrowed selection below avoids those environment-dependent subprocess tests.
3. `-m pytest -q tests/test_mvp_cli.py tests/test_mvp_finalize.py -k 'not collective and not two_rank and not huge_status and not one_rank_arbitrary' --maxfail=1`: **65 passed,22 deselected**.

TDD observed:
- Initial new contract run:18 failed/9 passed due absent helper/profile CLI/runtime/readiness/resource interfaces.
- Scoped receipt/source integer tests:5 failed/1 passed before fixes.
- Resource receipt identity tests:4 failed/2 passed before fixes.
- Direct private-train role test failed before role guard was added.
- The first red invalid-probe test unexpectedly reached existing CUDA availability/native-bf16 detection (no training/model/kernel execution); the test now explicitly forbids CUDA access via a guard double and passes only if rejected beforehand. No real GPU probes, jobs, model loading, or training were run.

Final scoped command (cwd integration worktree):

```sh
PYTHONPATH=src:revision/scripts/mvp /tmp/mvp-final-source-env/bin/python3.12 -m pytest -q tests/test_mvp_seed123_training.py tests/test_mvp_resource_probe.py tests/test_mvp_resource_fix1.py tests/test_mvp_readiness_tools.py tests/test_mvp_readiness_review.py tests/test_mvp_real_probes.py tests/test_mvp_cli.py tests/test_mvp_finalize.py -k 'not collective and not two_rank and not huge_status and not one_rank_arbitrary' --tb=short
```

**277 passed,22 deselected in79.94s**; output in `focused-tests.txt`. `git diff --check` passed. These are CPU contract/identity/arithmetic/publication tests, not hardware-readiness certification.

Advisor unavailable: client/model-version error, no advice/approval received. No global environment modifications. Graft queried before sources; controller should refresh shared graph after all workers integrate (no shared graph edits from this owner).

## Remaining gates

- Controller diff review and independent train/eval/panel integration checks; no commit/source hash freeze until then.
- Source closure freeze and fresh immutable deployment package, explicit schema2 controller budget (still not supplied), concrete epoch05 provenance/pins, allocation/live queue checks.
- Fresh six real-GPU readiness gates under development bindings; historical seed1/b660/three-seed receipts cannot be relabeled/copied.
- Real250-update training, then role-separated seed123 evaluation/quality review. No other seeds automatically scheduled.
- Existing remote jobs, old release, panel/data and prior receipts were not modified.
