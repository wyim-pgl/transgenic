# Immutable panel → seed123 compatibility (2026-09-17)

## Scope and status

Implemented only `revision/scripts/mvp/mvp_verify_panel_inputs.py`, new adjacent `mvp_panel_compatibility.py`, and `tests/test_mvp_panel_compatibility.py`. No producer/counts/runtime/training/profile-owner edits, commits, remote actions, actual DB scans, or accepted panel modifications. Advisor was unavailable (client/model-version mismatch), not an endorsement.

Historical authority is ONLY manifest SHA256 `7528c9bff5a9a9b177b1ad333ad76525a1d02d3c4cde4e0550865ff12e0acc0e` at `/data/gpfs/assoc/pgl/data/Transgenic/evidence/mvp50_reference_map_20260916/outputs/job-6165628/panel`. Root and all historical recorded paths must be canonical, absolute, present and non-symlink. No old source/request relocation or public trust override exists. Tests patch private trust constants for a synthetic 50-row / one-contig tiny DB; they do NOT prove accepted actual50 compatibility.

Read main execution plan, accepted panel-input/recovered deployment reviews and local actual50 numerical review. Local copied manifest was inspected for schema only; its JSONL is never substituted for authoritative DB selection.

## API / eval-owner handoff

- `mvp_panel_compatibility.verify_and_publish(input_path, out) -> report`: request and output are absolute paths; output parent must already exist and be canonical. Requires a CPU compute allocation (`SLURM_JOB_ID`, empty `CUDA_VISIBLE_DEVICES`). Publishes one external JSON receipt via existing closed/fsynced exclusive `.pending` and atomic no-replace hard link. Existing/pending outputs are refused; failed pending evidence retained.
- CLI: `python revision/scripts/mvp/mvp_panel_compatibility.py --input /absolute/current-request.json --out /absolute/fresh/compatibility.json`. **Template for a reviewed future compute allocation, not permission to run on a login node.** No job submitted here.
- Current request: `profile: "development-single"`, `panel_inputs` naming the pinned root (omission in verification request defaults to that root), existing `candidate`, `panels`, `fasta`, `reference`. Optional explicit `seed`/`aug_seed` must be integer 123/20261037. No old manifest rewriting.
- Consumer `mvp_verify_panel_inputs.load_panel_inputs(root, payload, panel, sequences)` keeps its signature and `(tracks, records)` return. ONLY explicit `payload['profile'] == 'development-single'` dispatches to compatibility. Requires `payload['panel_compatibility'] = {'path': '/absolute/compatibility.json', 'sha256': '<independently reviewed receipt digest>'}`. Never derive the expected digest from that receipt during consumption. Legacy current-producer branch is unchanged except factoring its read/artifact checks into private helpers.
- Consumer ALWAYS redoes current preflight, real FASTA slices, excluded-heldout selection and raster comparisons; there is no receipt-only bypass. Its returned records include current/historical source/data/artifacts, verification request and independent receipt identity for the decoder's existing final recheck.

### Source closures needed by eval owner

Add **`revision/scripts/mvp/mvp_panel_compatibility.py`** to decoder executable/code inventories and runtime/packaging closure wherever `mvp_verify_panel_inputs.py` is pinned; retain the verifier pin. Include newly owned **`src/transgenic/training/mvp_profiles.py`** as agreed with training owner. All new receipt generation must wait for final reviewed source bytes/paths; consumer path/byte changes invalidate a receipt.

`consumer_closure()` returns exact identities for helper, verifier, `mvp_prepare_panel_inputs.py`, `mvp_tracks.py`, `mvp_windows.py`, `mvp_cli.py`, `mvp_cli_runtime.py`, `mvp_produce_counts.py`, `mvp_decode.py`, `mvp_runtime.py`, `mvp_profiles.py`, `mvp_decode_panel.py`, and `mvp_decode_runtime.py`. This is the panel compatibility closure, not a replacement for the eval owner's full model/tokenizer/runtime closure. No producer-owned export change is needed: reused `preflight`, `panel_tracks`, `selected_provenance`, `fasta_sequences`, `stage_json`, `publish_staged`, and `recheck_files` already suffice.

## Verification semantics

- Pinned original manifest/COMPLETE, exact ordered 15 historical inputs (eight data, six source, original request); every original source/request rehashed at its recorded path.
- Current data reconciled by named panel/FASTA/reference/acceptance/inventory/receipts/corpus/evidence SHA256+size and acceptance pin; reference authority fields retained exactly, only corresponding current reference-file paths may differ when bytes match. Both old and current code identities are preserved, not stripped.
- All 150 artifacts and ordered 50 loci, actual authoritative FASTA slices, original-seed raster runs, exact selected provenance/member rows and support summaries checked by shared strict consumer logic.
- Actual seed123/aug20261037 full-retention RN=None excluded-heldout raster compared exactly as float16 to unchanged old array. Receipt records per-locus old artifact identities, measured four augmentation seeds, array-data SHA, selected molecule/member counts, member-count vector and support summaries. Current Python/NumPy/DuckDB/Torch versions and original NumPy/DuckDB versions retained.
- All sources, DB WAL presence (including symlink WAL), artifacts, request, and serialized pending receipt rechecked before publication. Absolute/non-symlink paths and external receipt placement required. Hard-link publication is individually atomic/no-replace, not protection against arbitrary later external writers.

## Focused tests

Initial RED: explicit development profile without independent receipt reached old COMPLETE loading; the new branch now rejects the missing pin first. Initial new-suite run: 11 pass / 2 test-hook errors (hook omitted existing `stage_json` return); fixed the test hook. A 26-test focused pass subsequently succeeded. Later passes encountered real concurrent eval-owner `mvp_produce_counts.py` edits and correctly failed the live source guard, not raster comparison; no source check was weakened. Latest combined run (`focused-tests.txt`): **27 passed, 1 failed** in 130.72s; the single failure was another concurrent eval-owner source-hash change during receipt production. The identical failing provenance test then passed unchanged, **1 passed in 9.57s** (`focused-rerun.txt`). Thus all 28 cases have passing observations, but the final 28-case suite has NOT yet passed in one source-stable invocation; controller must run that final freeze check. No guard was bypassed.

Environment: existing `/tmp/mvp-final-source-env/bin/python3.12`, NumPy1.26.4, DuckDB1.5.5, Torch2.6.0+cu124 (CPU arrays only), no install/full suite.

## Remaining actual job / blockers

A separately reviewed, budgeted CPU compute pass is still REQUIRED after final source freeze and eval-owner closure inclusion. It must retain access to all original historical source/request paths, accepted raw corpus/evidence DBs and frozen FASTA/GFF/Git authority; missing original source paths locally are expected and block an actual proof. This helper intentionally performs large hashes/current DB queries, so do not run the actual request locally or on login nodes. No receipt for accepted actual50 has been issued here. Independent review must inspect the actual pass/receipt/hash and scheduler accounting; job6165628 extern OOM and scientific/GPU readiness remain separate unresolved claims.
