# Evaluation integration interface (core implementation verified)

Owned writer: evaluation subagent; no commits/jobs/remote actions.

- Uses training owner's `transgenic.training.mvp_profiles` constants and `validate_seed_profile(profile, seed)`; does not recreate helper. Shared helper is present and tested through evaluation consumers.
- Development request: `profile: development-single`, `runs: {mvp_seed123: {run_role: mvp_finetune, seed: 123, checkpoint_sha256, final, code_manifest, launch_readiness: {path, sha256}, sif: {path, sha256}, config: {path, sha256}}, b5_seed123: {run_role: b5_baseline, seed: 123, checkpoint_sha256, weights: {path, sha256}}}`. Baseline weights identity is independently operator-supplied and must equal checked final initialization-audit bytes. Baseline has no augmentation/final/paired records.
- Prediction key `(profile, run_id, fraction, gene_id)`; each row additionally binds role, seed, checkpoint, window, exact file. Inventory exactly 150 with distinct baseline/final digests.
- Minimal panel compatibility API: retain `load_panel_inputs(panel_root, payload, panel, sequences)`; compatibility input identities returned in existing records list. Transport preserves optional `panel_compatibility` without relabeling old panel. Eval writer added helper to exact DECODER_ONLY and decode code-input inventories, never bypassing probe precedence or live-module rehash.
- Development scorer pairs keyed `mvp_seed123`; per-locus counts retain `seeds['123']` because baseline is not a paired treatment. Returns descriptive single-seed primary CE and composite diagnostic, decision null, no three-seed verification flags. Standalone caller counts remain unverified; producer counts require exact GFF provenance.
- Extra ONT wrapper/full structural-source producer linkage remains unfinished after this core pass; missing structural readouts explicit unknown, not zero or approval-pending. No real structural score or source substitution is claimed.
- `verify_evaluation_readiness(payload, candidate, runs)` reuses training `validate_launch_readiness`, additionally cross-binds final SIF and consumed-code identity. Consequently development producer/decoder currently require the bound training source checkout and external-package versions (training helper's existing exact gate); no relocated/cross-version adapter was invented. Standalone descriptive `mvp_score` remains CPU/lightweight and marks caller counts unverified.
- Exact final verification and run inventory are shared by decoder/producer. Decoder also validates readiness before model loading; final recheck repeats run/readiness checks. Producer retains all readiness/SIF/config and optional compatibility identities through final publication.
- Source-pin refresh is deliberately NOT performed. Current PROBE_CODE still names the reviewed legacy probe handshake; controller must freeze/review the integrated new probe source and real receipt/runtime closure after all writers finish, before operational development decode can pass. Adding a helper to DECODER_ONLY does not override any probe-consumed identity.

Final verification and scope: see [REPORT.md](REPORT.md).

Initial red: `/tmp/mvp-final-source-env/bin/python -m pytest -q tests/test_mvp_seed123_eval.py` -> 13 failed / 4 passed against old API (missing profile args, old three-seed rejection).
Advisor attempted planning; provider rejected client version; no advice/approval obtained.
