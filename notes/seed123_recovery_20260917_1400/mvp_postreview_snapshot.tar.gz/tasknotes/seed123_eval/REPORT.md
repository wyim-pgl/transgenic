# Seed123 evaluation core handoff — 2026-09-17

Worktree `/tmp/mvp-seed123-integration-20260917`, base `9603e20`. No commits, remote actions, jobs, actual training, model changes, panel rewrites or source-pin refresh.

## Implemented and verified

- Explicit development-single payload/CLI profile; omitted profile means legacy only. Shared training profile validator handles exact seed types. Conflicting profile/role/checkpoint metadata rejected.
- Distinct `mvp_seed123` / `b5_seed123` role keys, even though both seeds are 123. Development inventory is exactly 150: 50 fine-tune off, 50 on, 50 baseline off. Reject swapped roles/checkpoints, wrong window, duplicate identity, file aliases/hardlinks and repeated stems. Baseline checkpoint bytes must match the independently supplied operator pin and the final initialization audit; no baseline MVP augmentation.
- Decoder/producer share actual finalizer artifact/metadata/code/initialization verification. Development readiness uses the existing training verifier and additionally matches final SIF/code identity. No guard downgraded to identity_scope=test in production code.
- Role-dispatched decoding uses existing model loaders; 9603e20 reference-ID mapping functions unchanged. Raw GFF counts retain exact comparison/input provenance.
- Scorer/bootstrap support explicit single-seed paired CE and separate composite diagnostic; descriptive tile/locus bootstrap only, no final decision and no three-seed verification fields. Missing or partially missing structural observations are unassessable, not zero; partial observations do not produce pooled P/R.
- Panel owner's compatibility API is consumed unchanged. Optional pinned receipt survives transport and producer input identities. The new helper is bound in DECODER_ONLY/code inputs; tests verify live-module identity and probe-consumed precedence, not an exemption.
- Legacy 350-output finalizer→panel→decoder→producer path remains passing.

## Files changed by this writer only

- `revision/scripts/mvp/mvp_decode_panel.py`
- `revision/scripts/mvp/mvp_produce_counts.py`
- `revision/scripts/mvp/mvp_decode_runtime.py`
- `revision/scripts/mvp/mvp_score.py`
- `src/transgenic/evidence/mvp_bootstrap.py`
- `tests/test_mvp_seed123_eval.py` (new)
- `tests/test_mvp_score_producer.py` (fixture opt-in profile only)
- `tests/test_mvp_decoder_runtime.py`
- `tests/test_mvp_decoder_integration.py`
- `tasknotes/seed123_eval/{INTERFACE,REPORT}.md`

Shared worktree status also contains other owners' changes; those are not this writer's edits. Graft refreshed as an ignored cache.

## Reproduction and final results

Run from the worktree:

```sh
PYTHONPATH=$PWD/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
 /tmp/mvp-final-source-env/bin/python -m pytest -q \
 tests/test_mvp_seed123_eval.py tests/test_mvp_scoring.py \
 tests/test_mvp_score_producer.py tests/test_mvp_decoder_runtime.py --tb=short
```

**120 passed, 1 skipped** (existing version-conditional test), 57.66s.

```sh
PYTHONPATH=$PWD/src OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
 /tmp/mvp-final-source-env/bin/python -m pytest -q \
 tests/test_mvp_decoder_integration.py -k full_publication --tb=short
```

**2 passed, 22 deselected**, 214.04s. Both legacy350 and development150 traverse actual tiny finalizer artifacts, panel publication/verification, decoding normalization, GFF count production and statistics. Development invokes the real panel-compatibility reraster verifier with explicitly substituted synthetic historical authority pins. Remote encoder/generation/GPU runtime and GFFCompare executable are existing CPU test stand-ins; these tests are NOT actual GPU/scientific receipts. Development readiness mutation checks reject rehashed wrong profile/seed/role, failed resource gate, wrong SIF and wrong code digest.

`git diff --check` passed; `graft build` completed.

TDD reds were observed for missing development inventory/scoring/bootstrap APIs, CLI profile option/mismatch, helper runtime-closure coverage, missing readiness gate, metadata conflicts, repeated stems, partial missingness and three-seed flag removal before corresponding behavior changes.

An earlier extended focused invocation adding producer review/integration and reference suites timed out at 240s without a completed summary; **do not report that set as fully passing**. The first integration attempt without thread limits timed out at 120s. An intermediate integration run correctly rejected concurrent mutation of training owner's `mvp_cli_runtime.py`; no mutation check was weakened. The final completed runs above supersede those attempts for their listed scopes only.

## Precise remaining work / operational blockers

1. **Full long-read structural producer linkage is not implemented here.** Existing junction extraction/support functions remain unchanged; no new ONT wrapper or fabricated per-source counts/complete availability was added. Need bind actual accepted per-run alignment/junction producer receipts and approved source-OR/missingness before claiming measured structural P/R. Current producer truthfully emits missing/unassessable structural status. No A-HiFi substitution or complete STOP certification is authorized.
2. **Controller source/runtime freeze and independent review are still required.** `mvp_decode_runtime.PROBE_CODE` remains the reviewed legacy handshake pins. New training/probe edits require reviewed integrated pins and real receipts after all source writers finish; operational new-profile decode will fail closed against mismatched pins. No runtime imports are exempted because they are in DECODER_ONLY.
3. Development readiness currently reuses training's exact current checkout and package-version gate. A relocated/cross-version counts consumer needs a reviewed adapter, not a bypass. The supported same-checkout/same-packages CPU fixture path is tested; real runtime execution is not performed.
4. Final all-owner focused test synthesis/review and the extended reference/producer set remain controller work; no independent advisor review was obtained because the advisor call failed with a client/model version error.

See [INTERFACE.md](INTERFACE.md) for exact request/API fields. No approval was requested for already approved implementation work, and no deferred seed was run.
