# Pinned panel caller implementation

## Scope and status

Implemented only `revision/scripts/mvp/mvp_verify_pinned_panel.py`, `tests/test_mvp_pinned_panel.py`, and this tasknotes directory in `/tmp/mvp-seed123-integration-20260917`.

Read PANEL_REVIEW.md fully. Reused the reviewed `verify_and_publish`, `_canonical_path`, `_recheck`, file identity and JSON reader. No copied panel computation. Existing helper, decoder, runtime, scorer and existing tests were not edited by this task. The working tree had preexisting changes and parallel tasknotes; those were preserved.

The CLI requires `--input`, `--expected-sha256`, `--expected-size`, `--out`. Expected digest and size must come from the independently reviewed request, not current on-disk bytes at launch. It checks the expected identity before invoking the helper once, compares serialized receipt verification_request with the independently pinned path/hash/size, compares returned and serialized reports, and rechecks request and serialized-output identities before returning. The output identity snapshot is solely a late mutation guard, not an accepted external receipt pin. Exceptions propagate, preserving output/pending diagnostics without retries or deletion. CLI success emits no acceptance claim.

Existing helper allocation, no-GPU, canonical external output and no-clobber guards remain delegated and unchanged. Passing this caller gate is not independent receipt acceptance, source-closure approval, actual50 certification or GPU readiness.

## Local red/green evidence

All invocations used `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH=src:revision/scripts/mvp` and `/tmp/mvp-final-source-env/bin/python3.12 -m pytest -q` from the worktree.

- RED: `timeout 120 ... tests/test_mvp_pinned_panel.py`, exit 1, 22 failed in 2.49s. Expected missing-feature failures: `ModuleNotFoundError: mvp_verify_pinned_panel`. Tests were written and run before the implementation existed. Full log: `red.txt`.
- GREEN: same command, exit 0, 22 passed in 2.17s. Full log: `green.txt`.
- REGRESSION: `timeout 300 ... tests/test_mvp_pinned_panel.py tests/test_mvp_panel_compatibility.py revision/scripts/tests/test_mvp_panel_inputs.py`, exit 0, 50 passed in 143.50s. Full log: `focused.txt`.
- `git diff --check` exited 0. Reviewed helper hash stayed identical before and after tests.

Caller tests use synthetic intended bytes independently pinned before disk mutation, and replace only the expensive helper boundary for mutation/receipt scenarios. They cover entry replacement/mutation/wrong size/wrong digest, late request replacement/mutation/symlink, wrong receipt path/hash/size/extra key, serialized-versus-returned mismatch, valid CLI/API, noncanonical request, malformed expected pin, failure diagnostics/no retry, and the unmodified real helper's missing-allocation rejection. No fake Slurm allocation is used by the new tests. Existing synthetic panel tests do not certify real data.

## SHA256 inventory

- `revision/scripts/mvp/mvp_verify_pinned_panel.py`: `307749d202a0facdce86880cd1dad07c3da4e291099e5d2c99203c88f7b4dab2`
- `tests/test_mvp_pinned_panel.py`: `ba56c903e5ce0d8f9ba4f4d097e52dc3f1503eb2c111e084258105cc23a625be`
- Unchanged `revision/scripts/mvp/mvp_panel_compatibility.py`: `ffc67337496cae5c2b3cdcf3bfb708bac3d7d74f09ec96f4b618fc5c3e0a0aa2`
- `red.txt`: `e5711df11239bb10513ffb86bb3218e53c2fdc690d9d1efdeae098c8c6ca835d`
- `green.txt`: `4e67e85d39793073a89f09ff90345d4018a53fbd174aa7ead1628868ae6246d4`
- `focused.txt`: `e094eb27387eca015681b277a21cbda4da71241321345f27db53a363619ec594`

## Boundaries and follow-up

Completed caller implementation and bounded local verification. Final source-closure packaging and independent review are deferred to the separate requested phase, not implied complete here. No commit, remote command, scheduler action, real-corpus hashing, original-data edits, actual50 run or accepted real-data receipt occurred. As with the approved helper, observed checks cannot prevent arbitrary writes after the final guard.

Advisor consultation was attempted for a risk check but failed because the configured client does not support the model; no advisor endorsement is claimed. Graft source context was consulted before source inspection. Graft reported approximately 113175 tokens saved across three queries.
