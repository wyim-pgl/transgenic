"""Stdlib-only local negative checks; no SIF, CUDA, SSH or DB claims."""
import io
from pathlib import Path
import tarfile
import tempfile
import unittest
from deploy import parse_quota, pair_candidates, extract_archive, copy_cache, MODEL, REV, sha


class DeploymentTests(unittest.TestCase):
    def test_actual_quota_format_conservative(self):
        text = '| /work/nvme/bilv | 350G | 500G | 550G | 4482 | 2550000 | 2805000 |'
        value = parse_quota(text)
        self.assertEqual(value, 499 * 1000**3 - 351 * 1024**3)
        self.assertGreater(value, 45 * 2**30)
        self.assertLess(value, 150 * 2**30)

    def test_unknown_or_ambiguous_quota_fails(self):
        row = '| /work/nvme/bilv | 350G | 500G | 550G | 4482 | 2550000 | 2805000 |'
        for text in ('', row + '\n' + row, row.replace('350G', '350G*'),
                     row.replace('500G', '0'), row.replace('2550000', '4k')):
            with self.assertRaises(ValueError):
                parse_quota(text)

    def test_pair_identity_not_adjacent_rn_guess(self):
        rows = [{'rn': rn, 'chromosome': 'Chr1', 'start0': 10, 'end0': 30730, 'is_rc': rc}
                for rn, rc in ((99, True), (17, False))]
        pairs = pair_candidates(rows)
        self.assertEqual(pairs['30720'], [[17, 99]])
        self.assertEqual(pairs['61440'], [])
        with self.assertRaises(ValueError):
            pair_candidates(rows + rows[:1])
        rows[0]['end0'] += 1
        self.assertEqual(pair_candidates(rows)['30720'], [])

    def test_archive_rejects_link_and_escape(self):
        for name, link in (('../escape', False), ('evil', True)):
            with tempfile.TemporaryDirectory() as d:
                root = Path(d)
                archive = root / 'test.tar'
                with tarfile.open(archive, 'w') as t:
                    m = tarfile.TarInfo(name)
                    if link:
                        m.type = tarfile.SYMTYPE
                        m.linkname = '/tmp/unsafe'
                    else:
                        m.size = 1
                    t.addfile(m, None if link else io.BytesIO(b'x'))
                with self.assertRaises(ValueError):
                    extract_archive(archive, root / 'out', {})

    def test_cache_materializes_both_layouts_without_source_write(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            src = root / 'source'
            for layout, names in (('', ('special_tokens_map.json', 'tokenization_hyena.py', 'tokenizer_config.json')),
                                  ('hub', ('model.safetensors', 'config.json', 'configuration_hyena.py', 'modeling_hyena.py'))):
                model = src / layout / MODEL
                (model / 'refs').mkdir(parents=True)
                (model / 'refs/main').write_text(REV + '\n')
                (model / 'blobs').mkdir()
                snap = model / 'snapshots' / REV
                snap.mkdir(parents=True)
                for name in names:
                    blob = model / 'blobs' / name
                    blob.write_text(name)
                    (snap / name).symlink_to(blob)
            before = {str(p): sha(p) for p in src.rglob('*') if p.is_file()}
            dst = root / 'destination'
            copy_cache(src, dst)
            self.assertEqual(before, {str(p): sha(p) for p in src.rglob('*') if p.is_file()})
            self.assertFalse(any(p.is_symlink() for p in dst.rglob('*')))
            self.assertEqual(len([p for p in dst.rglob('*') if p.is_file()]), 9)
            with self.assertRaises(FileExistsError):
                copy_cache(src, dst)

    def test_cache_rejects_escape(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            src = root / 'source'
            model = src / MODEL
            (model / 'refs').mkdir(parents=True)
            (model / 'refs/main').write_text(REV)
            snap = model / 'snapshots' / REV
            snap.mkdir(parents=True)
            outside = root / 'outside'
            outside.write_text('unapproved')
            for name in ('special_tokens_map.json', 'tokenization_hyena.py', 'tokenizer_config.json'):
                (snap / name).symlink_to(outside)
            with self.assertRaises(ValueError):
                copy_cache(src, root / 'destination')


if __name__ == '__main__':
    unittest.main()
