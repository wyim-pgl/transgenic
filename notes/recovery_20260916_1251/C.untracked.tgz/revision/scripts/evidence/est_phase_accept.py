#!/usr/bin/env python3
"""Stage C2: HSP >= 30 aa route-B acceptance over raw13 blastx output. stdlib only.

Outputs are ACCEPTED HSP FRAME SPANS -- never "accepted phase evidence".
Phase evidence exists only after genomic projection (est_phase_project.py) and
the route-A cross-check; this stage only decomposes raw HSPs into
constant-frame query-nt sub-spans and applies the >= 30 aa acceptance rule.

OPERATIONAL DEFINITION OF ">= 30 aa" (must-fix 2) -- raw13 column 9 ('length')
is nonstandard under `diamond blastx --frameshift 15`.  Three candidate
readings exist and are all recorded per HSP in the output:
  (A) col9_alignment_length: DIAMOND's reported alignment length column,
      i.e. alignment columns including gap columns (aa units);
  (B) ungapped_query_aa: query codons actually consumed (BTOP match+mismatch
      columns with a query residue), gaps excluded;
  (C) per_frame_subspan_aa: the aa length of each constant-frame sub-span
      between frameshift ops.
ACCEPTANCE HERE USES READING (A): col9 >= 30.  This choice is PROVISIONAL
-- PROVISIONAL-until-RICH17-fixture: the real-DIAMOND RICH17 fixture extension
(est_phase_accept_fixture.py, compute job, not yet run) must pin what col 9
counts under --frameshift before this definition is frozen for production.
Counts under readings (B) and (C) are emitted in QC so the acceptance can be
re-derived without re-parsing if the fixture contradicts reading (A).

BTOP frameshift contract (from est_blastx_fixture.py, verified against DIAMOND
v2.1.24 src/basic/match.h + output/blast_tab_format.cpp on fixture job 6163396):
frameshift ops are the two-character pairs '\\-' and '/-'; the query cursor
shifts +1 nt ('\\') or -1 nt ('/') IN ORIENTED QUERY COORDINATES (the reverse
complement for negative frames), and each frameshift starts a new
constant-frame sub-span.  Production C2 execution is gated behind the WP1/A46
author decision (workplan section 4.6); this module is implementation +
fixtures only.
"""
from __future__ import annotations

import argparse
import importlib.util
import math
from pathlib import Path
import re
import signal
import sys

spec = importlib.util.spec_from_file_location('est_blastx', Path(__file__).with_name('est_blastx.py'))
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)

MIN_AA = 30  # frozen; no CLI override
ACCEPTANCE_DEFINITION = {
    'chosen': 'col9_alignment_length',
    'status': 'PROVISIONAL-until-RICH17-fixture',
    'candidates': {
        'A_col9_alignment_length': 'raw13 column 9 as reported by DIAMOND (alignment columns, aa units, gaps included)',
        'B_ungapped_query_aa': 'BTOP columns consuming a query codon (match+mismatch), gaps excluded',
        'C_per_frame_subspan_aa': 'aa length of each constant-frame sub-span between frameshift ops'},
    'rule': f'accept HSP iff column 9 >= {MIN_AA}',
    'terminology': 'outputs are accepted HSP frame spans, never accepted phase evidence'}
SPAN_FIELDS = ('qseqid qlen sseqid source_kind hsp_row subspan_index n_subspans strand '
               'signed_frame q_start q_end subspan_aa hsp_length_col9 hsp_ungapped_aa '
               'evalue bitscore btop_frameshift_ops').split()


def btop_tokens(btop):
    tokens = re.findall(r'\d+|[^\d][^\d]', btop)
    if ''.join(tokens) != btop:
        raise ValueError(f'invalid BTOP token stream: {btop!r}')
    return tokens


def decompose_hsp(qlen, qs, qe, frame, btop):
    """Decompose one HSP's BTOP into constant-frame query-nt sub-spans.

    Returns (subspans, ungapped_aa, n_frameshift_ops).  Each sub-span is a dict
    with ORIGINAL query coordinates (1-based inclusive), strand, and the signed
    frame recomputed at the sub-span start (sign = HSP strand; magnitude =
    oriented_start % 3 + 1, DIAMOND's own frame convention verified for the
    HSP start against column 12).
    """
    reverse = frame < 0
    if (qe >= qs) == reverse:
        raise ValueError('qstart/qend orientation disagrees with frame sign')
    pos = qlen - qs if reverse else qs - 1        # 0-based, oriented query
    end = qlen - qe + 1 if reverse else qe        # exclusive, oriented query
    if abs(frame) != pos % 3 + 1:
        raise ValueError(f'frame {frame} disagrees with oriented start {pos}')
    subspans, shifts, ungapped_aa = [], 0, 0
    span_start, span_aa = pos, 0

    def close():
        nonlocal span_start, span_aa
        if pos > span_start and span_aa > 0:
            if reverse:  # oriented [span_start, pos) -> original 1-based inclusive
                q_start, q_end = qlen - pos + 1, qlen - span_start
            else:
                q_start, q_end = span_start + 1, pos
            subspans.append(dict(q_start=q_start, q_end=q_end, subspan_aa=span_aa,
                                 strand='-' if reverse else '+',
                                 signed_frame=(-1 if reverse else 1) * (span_start % 3 + 1)))
        span_start, span_aa = pos, 0

    subject_cols = 0
    for token in btop_tokens(btop):
        if token.isdigit():
            n = int(token)
            if n <= 0:
                raise ValueError('BTOP match run must be positive')
            pos += 3 * n
            ungapped_aa += n
            span_aa += n
            subject_cols += n
            continue
        q, s = token
        if q in ('/', '\\'):
            if s != '-':
                raise ValueError(f'frameshift op must not consume subject: {token!r}')
            close()
            shift = 1 if q == '\\' else -1  # '\\' = +1 nt, '/' = -1 nt (oriented)
            pos += shift
            shifts += 1
            if not 0 <= pos <= qlen:
                raise ValueError('frameshift outside query')
            span_start = pos
        else:
            if q == '-' and s == '-':
                raise ValueError('double gap in BTOP')
            if q != '-':
                pos += 3
                ungapped_aa += 1
                span_aa += 1
            if s != '-':
                subject_cols += 1
    close()
    if pos != end:
        raise ValueError(f'BTOP does not consume reported query span: {pos} != {end}')
    return subspans, ungapped_aa, shifts, subject_cols


def parse_row(number, line):
    c = line.rstrip('\n').split('\t')
    if len(c) != 13 or any(not x for x in c):
        raise ValueError(f'malformed raw13 row {number}')
    qlen, slen = int(c[1]), int(c[3])
    qs, qe, ss, se, length = map(int, c[4:9])
    evalue, bitscore, frame = float(c[9]), float(c[10]), int(c[11])
    # Mirrors est_blastx.validate_raw row contract (C1 already enforced it on
    # the whole file; re-checked here so acceptance is safe standalone too).
    if not (1 <= qs <= qlen and 1 <= qe <= qlen and 1 <= ss <= se <= slen
            and length > 0 and frame in (-3, -2, -1, 1, 2, 3)
            and (qe >= qs) == (frame > 0) and math.isfinite(evalue)
            and 0 <= evalue <= 1e-5 and math.isfinite(bitscore) and bitscore > 0):
        raise ValueError(f'invalid raw coordinates/score at row {number}')
    return dict(qseqid=c[0], qlen=qlen, sseqid=c[2], slen=slen, qs=qs, qe=qe,
                ss=ss, se=se, length=length, evalue=evalue, bitscore=bitscore,
                frame=frame, btop=c[12])


def accept_stream(raw13, source_kind, out_tsv):
    qc = dict(rows_in=0, accepted_hsps=0, rejected_lt30=0, frameshift_ops_total=0,
              hsps_with_frameshift=0, subspans_emitted=0,
              would_accept_B_ungapped_aa_ge30=0, subspans_ge30=0,
              multi_frame_qseqids=0)
    multi_frame = set()
    seen_frames = {}
    with open(raw13) as f, open(out_tsv, 'x') as out:
        out.write('\t'.join(SPAN_FIELDS) + '\n')
        for number, line in enumerate(f, 1):
            row = parse_row(number, line)
            qc['rows_in'] += 1
            subspans, ungapped_aa, shifts, subject_cols = decompose_hsp(
                row['qlen'], row['qs'], row['qe'], row['frame'], row['btop'])
            if subject_cols != row['se'] - row['ss'] + 1:
                raise ValueError(f'BTOP does not consume reported subject span at row {number}')
            qc['frameshift_ops_total'] += shifts
            qc['hsps_with_frameshift'] += bool(shifts)
            if ungapped_aa >= MIN_AA:
                qc['would_accept_B_ungapped_aa_ge30'] += 1
            if row['length'] < MIN_AA:  # reading (A), PROVISIONAL -- see docstring
                qc['rejected_lt30'] += 1
                continue
            qc['accepted_hsps'] += 1
            frames = seen_frames.setdefault(row['qseqid'], set())
            frames.update(s['signed_frame'] for s in subspans)
            if len(frames) > 1:
                multi_frame.add(row['qseqid'])
            for index, s in enumerate(subspans):
                qc['subspans_emitted'] += 1
                qc['subspans_ge30'] += s['subspan_aa'] >= MIN_AA
                out.write('\t'.join(str(v) for v in (
                    row['qseqid'], row['qlen'], row['sseqid'], source_kind, number,
                    index, len(subspans), s['strand'], s['signed_frame'],
                    s['q_start'], s['q_end'], s['subspan_aa'], row['length'],
                    ungapped_aa, row['evalue'], row['bitscore'], shifts)) + '\n')
    qc['multi_frame_qseqids'] = len(multi_frame)
    return qc


def run(args):
    launcher.check_hash(args.raw13, args.raw13_sha256)  # C1 manifest binding gate
    with launcher.work_directory(args.out_dir) as out:
        tsv = out / 'accepted_hsp_frame_spans.tsv'
        qc = accept_stream(args.raw13, args.source_kind, tsv)
        launcher.check_hash(args.raw13, args.raw13_sha256)  # unchanged during read
        launcher.write_json(out / 'qc.json', dict(
            stage='C2 accepted HSP frame spans (NOT phase evidence)',
            species=args.species, source_kind=args.source_kind,
            raw13=str(Path(args.raw13).resolve()), raw13_sha256=args.raw13_sha256,
            acceptance_definition=ACCEPTANCE_DEFINITION, min_aa=MIN_AA,
            output_sha256=launcher.sha256(tsv), qc=qc,
            script_sha256=launcher.sha256(__file__),
            launcher_sha256=launcher.sha256(launcher.__file__)))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw13', type=Path, required=True)
    p.add_argument('--raw13-sha256', required=True,
                   help='must match the C1 audit manifest hash for this unit')
    p.add_argument('--source-kind', choices=('orthodb', 'swissprot'), required=True)
    p.add_argument('--species', required=True)
    p.add_argument('--out-dir', type=Path, required=True)
    args = p.parse_args(argv)

    def interrupted(signum, _frame):
        raise SystemExit(128 + signum)
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    run(args)
    return 0


if __name__ == '__main__':
    sys.exit(main())
