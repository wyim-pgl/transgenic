#!/usr/bin/env python3
"""Stage a pinned B5 checkpoint into the immutable layout MVP init consumes.

Track A must-fix 2 (B6 phase 2). ``weights_init.load_weights_only`` and
``mvp_cli_runtime._source_paths`` resolve ``--init-from <dir>`` as:

  <dir>/model.safetensors           weights (regular file, exact name)
  <dir>/../run_config.json          recipe authority (embedded normalized recipe)
  <dir>/../runtime_identity.txt     optional but staged here as required provenance

This script therefore produces a self-contained staged run root:

  <dest>/
    run_config.json          copied from the source run root, re-hashed
    runtime_identity.txt     copied from the source run root, re-hashed
    checkpoint/
      model.safetensors      copied from the pinned epoch dir, re-hashed
      eval.json, meta.json   copied when present (provenance; meta.json is
                             snapshotted by the loader when it exists)
    staging_receipt.json     measured source/staged hashes (atomic)
    STAGING_DONE             marker, written last (renameat2 NOREPLACE)

Pass ``--init-from <dest>/checkpoint`` to the MVP CLI. Because the staged
copy is disjoint from ``runs/seed123/``, later B5 epochs or ``best`` symlink
flips cannot mutate the MVP initialization.

The 2.09 GB copy and hashing MUST run inside a compute or data-mover
allocation (must-fix 6), never on a login node. This script only reads the
source; it never writes into the source run root.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[3]
for _entry in (str(_REPO_ROOT / "src"), str(_REPO_ROOT)):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_verified(source: Path, destination: Path, expected: str | None, label: str) -> dict:
    if not source.is_file():
        raise SystemExit(f"FAIL: {label} source is not a regular file: {source}")
    source_sha = _sha256(source)
    if expected is not None and source_sha != expected:
        raise SystemExit(f"FAIL: {label} source SHA256 {source_sha} != expected {expected}")
    shutil.copyfile(source, destination)
    staged_sha = _sha256(destination)
    if staged_sha != source_sha:
        raise SystemExit(f"FAIL: {label} staged copy SHA256 {staged_sha} != source {source_sha}")
    return {
        "source_path": str(source.resolve()), "staged_path": str(destination.resolve()),
        "sha256": staged_sha, "bytes": destination.stat().st_size,
        "expected_sha256": expected,
    }


def _atomic_json(destination: Path, value: dict) -> None:
    from transgenic.training.mvp_finalize import _rename_noreplace

    payload = (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()
    staging = destination.parent / (destination.name + ".tmp." + str(os.getpid()))
    descriptor = os.open(staging, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    _rename_noreplace(staging, destination)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--source-epoch", required=True,
                        help="pinned concrete epoch dir, e.g. .../runs/seed123/epoch_05 "
                             "(never the mutable 'best' symlink)")
    parser.add_argument("--dest", required=True, help="fresh staged run root")
    parser.add_argument("--expected-weights-sha256")
    parser.add_argument("--expected-run-config-sha256")
    parser.add_argument("--expected-runtime-identity-sha256")
    args = parser.parse_args(argv)

    source_epoch = Path(args.source_epoch).resolve(strict=True)
    if source_epoch.name == "best" or Path(args.source_epoch).name == "best":
        raise SystemExit("FAIL: refusing to stage via the mutable 'best' symlink; "
                         "pin a concrete epoch directory")
    source_root = source_epoch.parent
    destination = Path(args.dest).absolute()
    if os.path.lexists(destination):
        raise SystemExit(f"FAIL: staging destination must be fresh: {destination}")

    checkpoint = destination / "checkpoint"
    checkpoint.mkdir(parents=True)
    receipts = {
        "model.safetensors": _copy_verified(
            source_epoch / "model.safetensors", checkpoint / "model.safetensors",
            args.expected_weights_sha256, "weights"),
        "run_config.json": _copy_verified(
            source_root / "run_config.json", destination / "run_config.json",
            args.expected_run_config_sha256, "run_config.json"),
        "runtime_identity.txt": _copy_verified(
            source_root / "runtime_identity.txt", destination / "runtime_identity.txt",
            args.expected_runtime_identity_sha256, "runtime_identity.txt"),
    }
    for optional in ("eval.json", "meta.json"):
        candidate = source_epoch / optional
        if candidate.is_file():
            receipts[optional] = _copy_verified(candidate, checkpoint / optional, None, optional)

    run_config = json.loads((destination / "run_config.json").read_text(encoding="utf-8"))
    if not isinstance(run_config, dict) or run_config.get("seed") != 123:
        raise SystemExit("FAIL: staged run_config.json does not bind seed 123")

    receipt = {
        "schema_version": 1,
        "purpose": "mvp_init_checkpoint_staging",
        "output_use": "EXPLORATORY_MVP_NOT_FOR_PRODUCTION",
        "source_epoch": str(source_epoch),
        "staged_init_from": str(checkpoint),
        "files": receipts,
        "staged_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    _atomic_json(destination / "staging_receipt.json", receipt)
    from transgenic.training.mvp_finalize import _rename_noreplace
    marker_staging = destination / "STAGING_DONE.tmp"
    marker_staging.write_bytes(b"complete\n")
    _rename_noreplace(marker_staging, destination / "STAGING_DONE")
    print(json.dumps({"status": "staged", "init_from": str(checkpoint),
                      "weights_sha256": receipts["model.safetensors"]["sha256"]},
                     sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
