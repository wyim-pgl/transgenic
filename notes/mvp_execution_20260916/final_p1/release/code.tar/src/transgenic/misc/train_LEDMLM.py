#!/usr/bin/env python
import torch, os, wandb, gc
import torch.optim as optim
from torch.nn.utils import clip_grad_norm_
from transformers import get_linear_schedule_with_warmup
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from utils_transgenic import *
from configuration_transgenic import TransgenicHyenaConfig
from safetensors.torch import save_model
from modeling_HeynaTransgenic import transgenicForConditionalGeneration, LEDForConditionalMLM

os.environ['HF_HOME'] = './HFmodels'

def trainTransgenicFCGAccelerate(
	train_ds:isoformData, 
	eval_ds:isoformData, 
	lr, 
	num_epochs,  
	schedule_lr, 
	eval, 
	batch_size,
	max_grad_norm=1.0,
	checkpoint_path="checkpoints_FCG/",
	safetensors_model=None,
	output_dir="saved_models_FCG/",
	accumulation_steps=32,
	notes="",
	encoder_model="LongSafari/hyenadna-large-1m-seqlen-hf",
	unlink=False,
	log_wandb=True):

	if not os.path.exists(checkpoint_path):
		os.makedirs(checkpoint_path)
	if not os.path.exists(output_dir):
		os.makedirs(output_dir)

	# start a new wandb run to track this script
	if log_wandb:
		wandb.init(
			# set the wandb project where this run will be logged
			project="transgenic",

			# track hyperparameters and run metadata
			config={
			"learning_rate": lr,
			"schedule_lr": schedule_lr,
			"architecture": "LEDMLM",
			"dataset": "9G_6144nt",
			"epochs": num_epochs,
			"max_grad_norm": max_grad_norm,
			"accumulation_steps": accumulation_steps,
			"Optimizer": "AdamW",
			"Checkpoints":checkpoint_path,
			"Outputs":output_dir,
			"Notes":notes
			}
		)

	print(f"Training LEDMLM with HyenaTransgenicForConditionalGeneration. {checkpoint_path=} {output_dir=} {safetensors_model=}", file=sys.stderr)

	device = torch.device("cuda")
	print(f"Using: {device}", file=sys.stderr)
	
	# Set up DataLoaders
	torch.manual_seed(123)
	torch.cuda.manual_seed_all(123)
	train_ds = makeDataLoader(train_ds, shuffle=True, batch_size=batch_size, pin_memory=True, num_workers=4, collate_fn=hyena_collate_fn)
	eval_ds = makeDataLoader(eval_ds, shuffle=True, batch_size=batch_size, pin_memory=True, num_workers=4, collate_fn=hyena_collate_fn)
	
	
	# Initialize generation model
	config = TransgenicHyenaConfig(do_segment=False)
	genmodel = transgenicForConditionalGeneration(config)

	# Load weights
	decoder_checkpoint = "checkpoints/Hyena_Gen9G_6144nt_E30.safetensors"
	tensors = {}
	with safe_open(decoder_checkpoint, framework="pt", device="cpu") as f:
		for k in f.keys():
			if ("segmentation" not in k): 
				tensors[k] = f.get_tensor(k)

	genmodel.load_state_dict(tensors, strict=False)
	genmodel.to(device)
	genmodel.eval()

	# Load MLM model
	config = TransgenicHyenaConfig(do_segment=False, d_model=512)
	model = LEDForConditionalMLM(config)
	model.to(device)

	# Setup the optimizer
	optimizer = optim.AdamW(model.parameters(), lr=lr)
	optimizer.zero_grad()
	
	# Create the learning rate scheduler
	t_total = (len(train_ds) // accumulation_steps) * num_epochs
	if schedule_lr:
		lr_scheduler = get_linear_schedule_with_warmup(
		optimizer=optimizer,
		num_warmup_steps=t_total*0.05,
		num_training_steps=t_total
		)
	
	# Training loop
	best_eval_score = None
	for epoch in range(num_epochs):
		total_loss = 0
		mlm_steps = 0
		for step, batch in enumerate(tqdm(train_ds, miniters=10, disable=False)):
			if 'Zm' in batch[3][0]: 
				continue

			ii, am, lab = batch[0].to(device), batch[1].to(device), batch[2].to(device)
			try:
				encoder_outputs = genmodel.transgenic.encoder(ii)

				gen_outputs = genmodel.generate(
					encoder_outputs=encoder_outputs,
					#inputs=ii, 
					attention_mask=am, 
					num_return_sequences=1, 
					max_length=2048
				)
				pred = dt.batch_decode(gen_outputs.detach().cpu().numpy(), skip_special_tokens=True)[0].replace("|</s>", "").replace("</s>", "").replace("<s>", "")
				true = dt.batch_decode(batch[2].detach().cpu().numpy(), skip_special_tokens=True)[0].replace("|</s>", "").replace("</s>", "").replace("<s>", "")
				
				mlm_label = createDenoisingLabel(pred, true, dt)
				

				if mlm_label:
					tokenized_label = dt.batch_encode_plus(
						[mlm_label[0]],
						return_tensors="pt",
						padding=True,
						truncation=True,
						add_special_tokens=True,
						max_length=2048)

					outputs = model(
						inputs_embeds=encoder_outputs.last_hidden_state,
						labels=tokenized_label["input_ids"].to(device), 
						label_mask=mlm_label[1].to(device), 
						decoder_input_ids=gen_outputs[:, 1:],
						return_dict=True)
					
					total_loss += outputs.loss.detach().float()
					outputs.loss = outputs.loss / accumulation_steps
					outputs.loss.backward()
					mlm_steps += 1
			except:
				print(f"Error in batch: {batch[3]}")
			
			if (mlm_steps+1) % accumulation_steps == 0:
				clip_grad_norm_(model.parameters(), max_grad_norm)
				optimizer.step()
				if schedule_lr: lr_scheduler.step()
				# log metrics to wandb
				if log_wandb:
					wandb_log = {"epoch":epoch, "step":mlm_steps, "loss": outputs.loss.detach().float()*accumulation_steps, "mean_loss": (total_loss) / (mlm_steps+1), "lr": lr_scheduler.get_last_lr()[0]}
					for name, param in model.named_parameters():
						if (param.grad != None) & (param.requires_grad):
							grad_norm = param.grad.norm().detach().item()
							wandb_log[f"{name}_grad_norm"] = grad_norm
					wandb.log(wandb_log)
				optimizer.zero_grad()
			
			if (mlm_steps % 5000 == 0) & (step != 0):
				print(f"Epoch {epoch}, Step {step}, Loss {outputs.loss.detach().float()*accumulation_steps}", file=sys.stderr)
				save_model(model, f"{checkpoint_path}/model.safetensors")
			del gen_outputs
			torch.cuda.empty_cache()
			

		train_epoch_loss = total_loss / mlm_steps
		train_ppl = torch.exp(train_epoch_loss)

		if eval:
			eval_loss = 0
			for batch in tqdm(eval_ds, miniters=10, disable=False):
				ii, am, lab = batch[0].to(device), batch[1].to(device), batch[2].to(device)
				encoder_outputs = genmodel.transgenic.encoder(ii)

				gen_outputs = genmodel.generate(
					encoder_outputs=encoder_outputs,
					#inputs=ii, 
					attention_mask=am, 
					num_return_sequences=1, 
					max_length=2048
				)
				pred = dt.batch_decode(gen_outputs.detach().cpu().numpy(), skip_special_tokens=True)[0].replace("|</s>", "").replace("</s>", "").replace("<s>", "")
				true = dt.batch_decode(batch[2].detach().cpu().numpy(), skip_special_tokens=True)[0].replace("|</s>", "").replace("</s>", "").replace("<s>", "")
				
				mlm_label = createDenoisingLabel(pred, true, dt)
				

				if mlm_label:
					tokenized_label = dt.batch_encode_plus(
						[mlm_label[0]],
						return_tensors="pt",
						padding=True,
						truncation=True,
						add_special_tokens=True,
						max_length=2048)

					outputs = model(
						inputs_embeds=encoder_outputs.last_hidden_state,
						labels=tokenized_label["input_ids"].to(device), 
						label_mask=mlm_label[1].to(device), 
						decoder_input_ids=gen_outputs[:, 1:],
						return_dict=True)
					
					total_loss += outputs.loss.detach().float()
					outputs.loss = outputs.loss / accumulation_steps
					outputs.loss.backward()
					mlm_steps += 1
				
				eval_loss += outputs.loss.detach().float()

			eval_epoch_loss = eval_loss / len(eval_ds)
			eval_ppl = torch.exp(eval_epoch_loss)
			print(f"{epoch=}: {train_ppl=}, {train_epoch_loss=}, {eval_ppl=}, {eval_epoch_loss=}", file=sys.stderr)
			if log_wandb:
				wandb_log = {"epoch_train_ppl":train_ppl, "epoch_train_loss":train_epoch_loss, "epoch_eval_ppl":eval_ppl, "epoch_eval_loss":eval_epoch_loss}
				wandb.log(wandb_log)
		else:
			print(f"Epoch {epoch=}: {train_ppl=}, {train_epoch_loss=}", file=sys.stderr)
		
		if eval:
			if best_eval_score is None or eval_epoch_loss < best_eval_score:
				best_eval_score = eval_ppl
				if not os.path.exists("checkpoints"):
					os.makedirs("checkpoints", exist_ok=True)
				save_model(model, f"{checkpoint_path}/model.safetensors")
				print(f"New best model saved with {eval_epoch_loss=}", file=sys.stderr)
		else:
			if best_eval_score is None or train_epoch_loss < best_eval_score:
				best_eval_score = train_ppl
				if not os.path.exists("checkpoints"):
					os.makedirs("checkpoints", exist_ok=True)
				save_model(model, f"{checkpoint_path}/model.safetensors")
				print(f"New best model saved with {train_epoch_loss=}", file=sys.stderr)
		
		torch.cuda.empty_cache()
		gc.collect()
		total_loss = 0
		train_epoch_loss = 0
		train_ppl = 0
	
	if log_wandb:
		wandb.finish()


if __name__ == '__main__':
	torch.manual_seed(123)

	db="Generation_10G_static6144_addExtra200_addRCIsoOnly_clean.db"
	dt = GFFTokenizer()
	ds = isoformDataHyena(db, dt, mode="training", encoder_model="LongSafari/hyenadna-large-1m-seqlen-hf", global_attention=False)
	train_data, eval_data, test_data = torch.utils.data.random_split(ds, [339817, 45309,67964])

	trainTransgenicFCGAccelerate(
		train_data, 
		eval_data, 
		lr=5e-5, 
		num_epochs=15, 
		schedule_lr=True, 
		eval=True, 
		batch_size=1, 
		accumulation_steps=64,
		checkpoint_path="checkpoints_LEDMLM/", 
		safetensors_model=None,
		output_dir="saved_models_LEDMLM/",
		max_grad_norm=1,
		notes="Training with Hyena",
		encoder_model="LongSafari/hyenadna-large-1m-seqlen-hf",
		unlink = False,
		log_wandb=True
	)